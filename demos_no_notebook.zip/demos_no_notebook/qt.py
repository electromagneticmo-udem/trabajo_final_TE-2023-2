from vpython import *
set_browser(type='pyqt')
b = box()
scene.caption = "A box should appear in the window above"
